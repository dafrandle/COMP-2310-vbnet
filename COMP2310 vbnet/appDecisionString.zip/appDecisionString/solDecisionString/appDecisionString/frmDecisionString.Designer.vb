﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDecisionString
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.nameBoxFirst = New System.Windows.Forms.TextBox()
        Me.dataUseBox = New System.Windows.Forms.TextBox()
        Me.nameBoxLast = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.priceLable = New System.Windows.Forms.Label()
        Me.priceIndLable = New System.Windows.Forms.Label()
        Me.receipt = New System.Windows.Forms.TextBox()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.line3 = New System.Windows.Forms.RadioButton()
        Me.line2 = New System.Windows.Forms.RadioButton()
        Me.line1 = New System.Windows.Forms.RadioButton()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.plan5 = New System.Windows.Forms.RadioButton()
        Me.plan4 = New System.Windows.Forms.RadioButton()
        Me.plan3 = New System.Windows.Forms.RadioButton()
        Me.plan2 = New System.Windows.Forms.RadioButton()
        Me.plan1 = New System.Windows.Forms.RadioButton()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.phoneNumberBox = New System.Windows.Forms.TextBox()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.lableIDNum = New System.Windows.Forms.Label()
        Me.phoneNumFormat = New System.Windows.Forms.Label()
        Me.userInfoSubmitButton = New System.Windows.Forms.Button()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(9, 7)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(71, 26)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(9, 68)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 20)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Last:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(10, 38)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 20)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "First:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(222, 7)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(159, 26)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Phone Number"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(2, 20)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(384, 26)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Number of Gigabytes used this month:"
        '
        'nameBoxFirst
        '
        Me.nameBoxFirst.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nameBoxFirst.Location = New System.Drawing.Point(56, 36)
        Me.nameBoxFirst.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.nameBoxFirst.Name = "nameBoxFirst"
        Me.nameBoxFirst.Size = New System.Drawing.Size(161, 26)
        Me.nameBoxFirst.TabIndex = 0
        Me.nameBoxFirst.Text = "Roy"
        '
        'dataUseBox
        '
        Me.dataUseBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dataUseBox.Location = New System.Drawing.Point(390, 17)
        Me.dataUseBox.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dataUseBox.MaxLength = 8
        Me.dataUseBox.Name = "dataUseBox"
        Me.dataUseBox.Size = New System.Drawing.Size(101, 32)
        Me.dataUseBox.TabIndex = 0
        Me.dataUseBox.Text = "25"
        '
        'nameBoxLast
        '
        Me.nameBoxLast.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nameBoxLast.Location = New System.Drawing.Point(56, 65)
        Me.nameBoxLast.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.nameBoxLast.Name = "nameBoxLast"
        Me.nameBoxLast.Size = New System.Drawing.Size(161, 26)
        Me.nameBoxLast.TabIndex = 1
        Me.nameBoxLast.Text = "Gbiv"
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Label51)
        Me.Panel1.Controls.Add(Me.priceLable)
        Me.Panel1.Controls.Add(Me.priceIndLable)
        Me.Panel1.Controls.Add(Me.receipt)
        Me.Panel1.Controls.Add(Me.Label49)
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Controls.Add(Me.Label48)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.dataUseBox)
        Me.Panel1.Location = New System.Drawing.Point(378, -13)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(592, 616)
        Me.Panel1.TabIndex = 4
        '
        'priceLable
        '
        Me.priceLable.AutoSize = True
        Me.priceLable.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.priceLable.Location = New System.Drawing.Point(127, 522)
        Me.priceLable.Name = "priceLable"
        Me.priceLable.Size = New System.Drawing.Size(85, 24)
        Me.priceLable.TabIndex = 15
        Me.priceLable.Text = "$0000.00"
        Me.priceLable.Visible = False
        '
        'priceIndLable
        '
        Me.priceIndLable.AutoSize = True
        Me.priceIndLable.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.priceIndLable.Location = New System.Drawing.Point(62, 480)
        Me.priceIndLable.Name = "priceIndLable"
        Me.priceIndLable.Size = New System.Drawing.Size(115, 25)
        Me.priceIndLable.TabIndex = 14
        Me.priceIndLable.Text = "Total Price"
        '
        'receipt
        '
        Me.receipt.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.receipt.Font = New System.Drawing.Font("Consolas", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.receipt.Location = New System.Drawing.Point(53, 257)
        Me.receipt.Multiline = True
        Me.receipt.Name = "receipt"
        Me.receipt.ReadOnly = True
        Me.receipt.Size = New System.Drawing.Size(438, 207)
        Me.receipt.TabIndex = 13
        Me.receipt.Text = "No plan set"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.Location = New System.Drawing.Point(324, 74)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(94, 24)
        Me.Label49.TabIndex = 12
        Me.Label49.Text = "Line Type"
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.line3)
        Me.Panel3.Controls.Add(Me.line2)
        Me.Panel3.Controls.Add(Me.line1)
        Me.Panel3.Location = New System.Drawing.Point(298, 85)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(193, 159)
        Me.Panel3.TabIndex = 2
        '
        'line3
        '
        Me.line3.AutoSize = True
        Me.line3.Location = New System.Drawing.Point(29, 115)
        Me.line3.Name = "line3"
        Me.line3.Size = New System.Drawing.Size(72, 17)
        Me.line3.TabIndex = 2
        Me.line3.TabStop = True
        Me.line3.Text = "Non-Profit"
        Me.line3.UseVisualStyleBackColor = True
        '
        'line2
        '
        Me.line2.AutoSize = True
        Me.line2.Location = New System.Drawing.Point(29, 69)
        Me.line2.Name = "line2"
        Me.line2.Size = New System.Drawing.Size(67, 17)
        Me.line2.TabIndex = 1
        Me.line2.TabStop = True
        Me.line2.Text = "Business"
        Me.line2.UseVisualStyleBackColor = True
        '
        'line1
        '
        Me.line1.AutoSize = True
        Me.line1.Location = New System.Drawing.Point(29, 23)
        Me.line1.Name = "line1"
        Me.line1.Size = New System.Drawing.Size(66, 17)
        Me.line1.TabIndex = 0
        Me.line1.TabStop = True
        Me.line1.Text = "Personal"
        Me.line1.UseVisualStyleBackColor = True
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.Location = New System.Drawing.Point(79, 74)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(47, 24)
        Me.Label48.TabIndex = 10
        Me.Label48.Text = "Plan"
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.plan5)
        Me.Panel2.Controls.Add(Me.plan4)
        Me.Panel2.Controls.Add(Me.plan3)
        Me.Panel2.Controls.Add(Me.plan2)
        Me.Panel2.Controls.Add(Me.plan1)
        Me.Panel2.Location = New System.Drawing.Point(53, 85)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(193, 159)
        Me.Panel2.TabIndex = 1
        '
        'plan5
        '
        Me.plan5.AutoSize = True
        Me.plan5.Location = New System.Drawing.Point(29, 115)
        Me.plan5.Name = "plan5"
        Me.plan5.Size = New System.Drawing.Size(58, 17)
        Me.plan5.TabIndex = 4
        Me.plan5.TabStop = True
        Me.plan5.Text = "Gigabit"
        Me.plan5.UseVisualStyleBackColor = True
        '
        'plan4
        '
        Me.plan4.AutoSize = True
        Me.plan4.Location = New System.Drawing.Point(29, 92)
        Me.plan4.Name = "plan4"
        Me.plan4.Size = New System.Drawing.Size(81, 17)
        Me.plan4.TabIndex = 3
        Me.plan4.TabStop = True
        Me.plan4.Text = "High Speed"
        Me.plan4.UseVisualStyleBackColor = True
        '
        'plan3
        '
        Me.plan3.AutoSize = True
        Me.plan3.Location = New System.Drawing.Point(29, 69)
        Me.plan3.Name = "plan3"
        Me.plan3.Size = New System.Drawing.Size(62, 17)
        Me.plan3.TabIndex = 2
        Me.plan3.TabStop = True
        Me.plan3.Text = "Express"
        Me.plan3.UseVisualStyleBackColor = True
        '
        'plan2
        '
        Me.plan2.AutoSize = True
        Me.plan2.Location = New System.Drawing.Point(29, 46)
        Me.plan2.Name = "plan2"
        Me.plan2.Size = New System.Drawing.Size(58, 17)
        Me.plan2.TabIndex = 1
        Me.plan2.TabStop = True
        Me.plan2.Text = "Lifeline"
        Me.plan2.UseVisualStyleBackColor = True
        '
        'plan1
        '
        Me.plan1.AutoSize = True
        Me.plan1.Location = New System.Drawing.Point(29, 23)
        Me.plan1.Name = "plan1"
        Me.plan1.Size = New System.Drawing.Size(60, 17)
        Me.plan1.TabIndex = 0
        Me.plan1.TabStop = True
        Me.plan1.Text = "Dial-Up"
        Me.plan1.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel1.ColumnCount = 4
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.00062!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.00063!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.00063!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.99813!))
        Me.TableLayoutPanel1.Controls.Add(Me.Label36, 3, 9)
        Me.TableLayoutPanel1.Controls.Add(Me.Label35, 0, 9)
        Me.TableLayoutPanel1.Controls.Add(Me.Label33, 1, 9)
        Me.TableLayoutPanel1.Controls.Add(Me.Label7, 1, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label32, 2, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.Label31, 1, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.Label30, 0, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.Label29, 2, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.Label28, 1, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.Label27, 0, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.Label24, 0, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.Label23, 2, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Label22, 1, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Label21, 0, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Label9, 0, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label6, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label10, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label11, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label12, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label15, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label16, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label17, 2, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label18, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label20, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label26, 3, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.Label25, 2, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.Label14, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label13, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label37)
        Me.TableLayoutPanel1.Controls.Add(Me.Label38, 1, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.Label39)
        Me.TableLayoutPanel1.Controls.Add(Me.Label40, 3, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label41, 3, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label42, 3, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label43, 3, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Label44, 3, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.Label45, 3, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.Label8, 2, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label34, 2, 9)
        Me.TableLayoutPanel1.Controls.Add(Me.Label46, 1, 2)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(2, 146)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 10
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0001!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0001!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0001!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0001!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0001!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0001!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0001!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0001!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0001!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.999101!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(374, 413)
        Me.TableLayoutPanel1.TabIndex = 9
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(282, 370)
        Me.Label36.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(80, 18)
        Me.Label36.TabIndex = 30
        Me.Label36.Text = "No change"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(3, 370)
        Me.Label35.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(71, 36)
        Me.Label35.TabIndex = 29
        Me.Label35.Text = "Personal Line"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(96, 370)
        Me.Label33.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(44, 18)
        Me.Label33.TabIndex = 27
        Me.Label33.Text = "None"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(96, 165)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(74, 36)
        Me.Label7.TabIndex = 1
        Me.Label7.Text = "100 Gigabytes"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(189, 329)
        Me.Label32.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(64, 36)
        Me.Label32.TabIndex = 26
        Me.Label32.Text = "200% increase"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(96, 329)
        Me.Label31.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(70, 18)
        Me.Label31.TabIndex = 25
        Me.Label31.Text = "10x more"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(3, 329)
        Me.Label30.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(73, 36)
        Me.Label30.TabIndex = 24
        Me.Label30.Text = "Business Line"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(189, 288)
        Me.Label29.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(64, 36)
        Me.Label29.TabIndex = 23
        Me.Label29.Text = "20% discount"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(96, 288)
        Me.Label28.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(62, 18)
        Me.Label28.TabIndex = 22
        Me.Label28.Text = "3x more"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(3, 288)
        Me.Label27.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(80, 36)
        Me.Label27.TabIndex = 21
        Me.Label27.Text = "Non-Profit Line"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(3, 247)
        Me.Label24.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(86, 20)
        Me.Label24.TabIndex = 18
        Me.Label24.Text = "Line Type"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(189, 206)
        Me.Label23.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(85, 36)
        Me.Label23.TabIndex = 17
        Me.Label23.Text = "$165.00 per month"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(96, 206)
        Me.Label22.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(74, 36)
        Me.Label22.TabIndex = 16
        Me.Label22.Text = "300 Gigabytes"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(3, 206)
        Me.Label21.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(86, 36)
        Me.Label21.TabIndex = 15
        Me.Label21.Text = "Gigabit          1 gbit/s **"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(3, 165)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(88, 36)
        Me.Label9.TabIndex = 3
        Me.Label9.Text = "High Speed 60 mbit/s **"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(3, 1)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(44, 20)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Plan"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(3, 42)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(78, 36)
        Me.Label10.TabIndex = 4
        Me.Label10.Text = "Dial-up      56 kbit/s"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(3, 83)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(85, 36)
        Me.Label11.TabIndex = 5
        Me.Label11.Text = "Lifeline        5 mbit/s"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(3, 124)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(78, 36)
        Me.Label12.TabIndex = 6
        Me.Label12.Text = "Express    25 mbit/s"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(189, 42)
        Me.Label15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(73, 36)
        Me.Label15.TabIndex = 9
        Me.Label15.Text = "$5.00 per month"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(189, 83)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(81, 36)
        Me.Label16.TabIndex = 10
        Me.Label16.Text = "$20.00 per month"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(189, 124)
        Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(81, 36)
        Me.Label17.TabIndex = 11
        Me.Label17.Text = "$50.00 per month"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(96, 124)
        Me.Label18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(74, 36)
        Me.Label18.TabIndex = 12
        Me.Label18.Text = "30 Gigabytes"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(96, 42)
        Me.Label20.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(69, 18)
        Me.Label20.TabIndex = 14
        Me.Label20.Text = "Unlimited"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(282, 247)
        Me.Label26.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(83, 40)
        Me.Label26.TabIndex = 20
        Me.Label26.Text = "Overage Difference"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(189, 247)
        Me.Label25.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(83, 40)
        Me.Label25.TabIndex = 19
        Me.Label25.Text = "Price Difference"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(282, 1)
        Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(81, 40)
        Me.Label14.TabIndex = 8
        Me.Label14.Text = "Overage Charge"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(189, 1)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(49, 20)
        Me.Label13.TabIndex = 7
        Me.Label13.Text = "Price"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(96, 1)
        Me.Label37.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(53, 40)
        Me.Label37.TabIndex = 31
        Me.Label37.Text = "Data Limit"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(96, 247)
        Me.Label38.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(56, 40)
        Me.Label38.TabIndex = 32
        Me.Label38.Text = "Extra Data"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(282, 42)
        Me.Label39.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(32, 18)
        Me.Label39.TabIndex = 33
        Me.Label39.Text = "N/A"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(282, 83)
        Me.Label40.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(52, 18)
        Me.Label40.TabIndex = 34
        Me.Label40.Text = "$10.00"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(282, 124)
        Me.Label41.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(44, 18)
        Me.Label41.TabIndex = 35
        Me.Label41.Text = "$5.00"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(282, 165)
        Me.Label42.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(52, 18)
        Me.Label42.TabIndex = 36
        Me.Label42.Text = "$20.00"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(282, 206)
        Me.Label43.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(52, 18)
        Me.Label43.TabIndex = 37
        Me.Label43.Text = "$50.00"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.Location = New System.Drawing.Point(282, 288)
        Me.Label44.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(64, 36)
        Me.Label44.TabIndex = 38
        Me.Label44.Text = "50% discount"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.Location = New System.Drawing.Point(282, 329)
        Me.Label45.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(64, 36)
        Me.Label45.TabIndex = 39
        Me.Label45.Text = "10% discount"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(189, 165)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(81, 36)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "$95.00 per month"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(189, 370)
        Me.Label34.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(80, 18)
        Me.Label34.TabIndex = 28
        Me.Label34.Text = "No change"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(96, 83)
        Me.Label46.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(86, 18)
        Me.Label46.TabIndex = 40
        Me.Label46.Text = "5 Gigabytes"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(-1, 562)
        Me.Label19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(117, 13)
        Me.Label19.TabIndex = 10
        Me.Label19.Text = "** Subject to availability"
        '
        'phoneNumberBox
        '
        Me.phoneNumberBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.phoneNumberBox.Location = New System.Drawing.Point(224, 35)
        Me.phoneNumberBox.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.phoneNumberBox.Name = "phoneNumberBox"
        Me.phoneNumberBox.Size = New System.Drawing.Size(140, 26)
        Me.phoneNumberBox.TabIndex = 2
        Me.phoneNumberBox.Text = "555-555-5555"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.Location = New System.Drawing.Point(173, 97)
        Me.Label47.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(30, 20)
        Me.Label47.TabIndex = 11
        Me.Label47.Text = "ID:"
        '
        'lableIDNum
        '
        Me.lableIDNum.AutoSize = True
        Me.lableIDNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lableIDNum.Location = New System.Drawing.Point(207, 97)
        Me.lableIDNum.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lableIDNum.Name = "lableIDNum"
        Me.lableIDNum.Size = New System.Drawing.Size(105, 20)
        Me.lableIDNum.TabIndex = 12
        Me.lableIDNum.Text = "ID GO HERE"
        Me.lableIDNum.Visible = False
        '
        'phoneNumFormat
        '
        Me.phoneNumFormat.AutoSize = True
        Me.phoneNumFormat.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.phoneNumFormat.Location = New System.Drawing.Point(207, 120)
        Me.phoneNumFormat.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.phoneNumFormat.Name = "phoneNumFormat"
        Me.phoneNumFormat.Size = New System.Drawing.Size(115, 20)
        Me.phoneNumFormat.TabIndex = 13
        Me.phoneNumFormat.Text = "Phone Number"
        Me.phoneNumFormat.Visible = False
        '
        'userInfoSubmitButton
        '
        Me.userInfoSubmitButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.userInfoSubmitButton.Location = New System.Drawing.Point(224, 65)
        Me.userInfoSubmitButton.Name = "userInfoSubmitButton"
        Me.userInfoSubmitButton.Size = New System.Drawing.Size(140, 26)
        Me.userInfoSubmitButton.TabIndex = 3
        Me.userInfoSubmitButton.Text = "Submit"
        Me.userInfoSubmitButton.UseVisualStyleBackColor = True
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.Location = New System.Drawing.Point(11, 120)
        Me.Label50.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(192, 20)
        Me.Label50.TabIndex = 14
        Me.Label50.Text = "Formated Phone Number:"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(132, 574)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(286, 13)
        Me.Label51.TabIndex = 16
        Me.Label51.Text = "See ""test data for various combinations"" at bottom of code." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'frmDecisionString
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(947, 595)
        Me.Controls.Add(Me.Label50)
        Me.Controls.Add(Me.userInfoSubmitButton)
        Me.Controls.Add(Me.phoneNumFormat)
        Me.Controls.Add(Me.lableIDNum)
        Me.Controls.Add(Me.Label47)
        Me.Controls.Add(Me.phoneNumberBox)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.nameBoxLast)
        Me.Controls.Add(Me.nameBoxFirst)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.MaximumSize = New System.Drawing.Size(963, 634)
        Me.MinimumSize = New System.Drawing.Size(963, 634)
        Me.Name = "frmDecisionString"
        Me.Text = "Decision String"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents nameBoxFirst As TextBox
    Friend WithEvents dataUseBox As TextBox
    Friend WithEvents nameBoxLast As TextBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents Label6 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Label45 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents phoneNumberBox As TextBox
    Friend WithEvents Label47 As Label
    Friend WithEvents lableIDNum As Label
    Friend WithEvents phoneNumFormat As Label
    Friend WithEvents userInfoSubmitButton As Button
    Friend WithEvents Label48 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label49 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents line3 As RadioButton
    Friend WithEvents line2 As RadioButton
    Friend WithEvents line1 As RadioButton
    Friend WithEvents plan5 As RadioButton
    Friend WithEvents plan4 As RadioButton
    Friend WithEvents plan3 As RadioButton
    Friend WithEvents plan2 As RadioButton
    Friend WithEvents plan1 As RadioButton
    Friend WithEvents receipt As TextBox
    Friend WithEvents Label50 As Label
    Friend WithEvents priceIndLable As Label
    Friend WithEvents priceLable As Label
    Friend WithEvents Label51 As Label
End Class
